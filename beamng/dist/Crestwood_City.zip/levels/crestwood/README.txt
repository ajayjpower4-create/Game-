CRESTWOOD - a BeamNG.drive level
================================

INSTALL
  1. Open BeamNG.drive once so the user folder exists.
  2. Put Crestwood_City.zip (this whole zip, do NOT unpack it) into:
       Windows : Documents\BeamNG.drive\<version>\mods\
       Linux   : ~/.local/share/BeamNG.drive/<version>/mods/
       macOS   : ~/Library/Application Support/BeamNG.drive/<version>/mods/
     <version> is the game version folder, e.g. 0.36
  3. Start the game. Single Player -> New Game / Freeroam -> pick "Crestwood".
     First load takes a little longer while the game caches the meshes.

WHAT IS IN IT
  * A four lane ring beltway around the entire city (about 6 km lap).
  * Crestwood Apartments: ten walk-up blocks, leasing office, pool, parking.
  * Crestwood High School: two storey building, gym, stadium with a running
    track, bleachers and goal posts, bus loop and staff parking.
  * KRST 98.7: broadcast building with roof dishes plus a 118 m guyed lattice
    mast with aviation banding and beacons.
  * Five residential streets, ninety houses with garages, driveways and sheds.
  * Downtown: office towers, strip malls, a gas station, freight yards and a
    water tower.

SPAWN POINTS
  Main Street (default), Crestwood Apartments, Crestwood High School,
  KRST 98.7 Radio, Beltway.

UNINSTALL
  Delete the zip from the mods folder.
