CRESTWOOD - a BeamNG.drive level
================================

INSTALL
  1. Open BeamNG.drive once so the user folder exists.
  2. Put Crestwood_City.zip (this whole zip, do NOT unpack it) into:
       Windows : Documents\BeamNG.drive\<version>\mods\
       Linux   : ~/.local/share/BeamNG.drive/<version>/mods/
       macOS   : ~/Library/Application Support/BeamNG.drive/<version>/mods/
     <version> is the game version folder, e.g. 0.36
  3. Start the game. Single Player -> Freeroam -> pick "Crestwood".
     First load takes a while as the game caches every mesh.

WHAT IS IN IT
  * 4.4 km x 4.4 km level with a four lane ring beltway, about a 10 km lap.
  * A 36 block city grid with two-lane streets and four-lane arterials.
  * Crestwood Apartments: fifteen walk-up blocks over four city blocks, with
    leasing office, pool, drive loops and parking bays.
  * Crestwood High School: main building, gym, bus loop, staff parking, and a
    stadium with running track, bleachers and goal posts.
  * KRST 98.7 across four blocks: broadcast building, dish farm, a 152 m guyed
    lattice mast and an 84 m backup mast.
  * Twelve residential streets, about 200 houses with garages and driveways.
  * Downtown towers, strip malls, a gas station, freight yards, water towers.

SPAWN POINTS
  Main Street (default), Crestwood Apartments, Crestwood High School,
  KRST 98.7 Radio, Beltway.

UNINSTALL
  Delete the zip from the mods folder.
